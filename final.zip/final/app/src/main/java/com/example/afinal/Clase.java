package com.example.afinal;

public class Clase {
    private String claseId;
    private String claseClassroom;
    private String claseLevel;
    private String claseName;
    private  String claseProfessor;
    private String claseTime;

    public Clase() {
    }

    public Clase(String claseId, String claseClassroom, String claseLevel, String claseName, String claseProfessor, String claseTime) {
        this.claseId = claseId;
        this.claseClassroom = claseClassroom;
        this.claseLevel = claseLevel;
        this.claseName = claseName;
        this.claseProfessor = claseProfessor;
        this.claseTime = claseTime;
    }

    public String getClaseId() {
        return claseId;
    }

    public void setClaseId(String claseId) {
        this.claseId = claseId;
    }

    public String getClaseClassroom() {
        return claseClassroom;
    }

    public void setClaseClassroom(String claseClassroom) {
        this.claseClassroom = claseClassroom;
    }

    public String getClaseLevel() {
        return claseLevel;
    }

    public void setClaseLevel(String claseLevel) {
        this.claseLevel = claseLevel;
    }

    public String getClaseName() {
        return claseName;
    }

    public void setClaseName(String claseName) {
        this.claseName = claseName;
    }

    public String getClaseProfessor() {
        return claseProfessor;
    }

    public void setClaseProfessor(String claseProfessor) {
        this.claseProfessor = claseProfessor;
    }

    public String getClaseTime() {
        return claseTime;
    }

    public void setClaseTime(String claseTime) {
        this.claseTime = claseTime;
    }
}


