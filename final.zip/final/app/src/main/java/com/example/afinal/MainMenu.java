package com.example.afinal;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainMenu extends AppCompatActivity {
    Button btnVerClase;
    Button btnVerMaestro;
    Button btnAgregarMaestro;
    Button btnAgregarClase;
    FirebaseDatabase database;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

         database = FirebaseDatabase.getInstance();


        btnVerClase = findViewById(R.id.viewClases);
        btnVerMaestro = findViewById(R.id.viewMaestros);
        btnAgregarMaestro = findViewById(R.id.addMaestros);
        btnAgregarClase = findViewById(R.id.addClases);
        btnVerClase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainMenu.this, verClases.class);
                startActivity(intent);
            }
        });
        btnVerMaestro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainMenu.this, verMaestros.class);
                startActivity(intent);
            }
        });
        btnAgregarMaestro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseReference myRef = database.getReference("message");
                myRef.setValue("Hello, World!");
                //Intent intent = new Intent(MainMenu.this, agregarMaestros.class);
               // startActivity(intent);
            }
        });
        btnAgregarClase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainMenu.this, agregarClases.class);
                startActivity(intent);
            }
        });
    }
}
